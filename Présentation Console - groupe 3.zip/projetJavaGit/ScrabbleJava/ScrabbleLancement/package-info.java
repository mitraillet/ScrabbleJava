/**
*Ce package contient le fichier de lancement du jeu
*<ul>
*<li>La classe <code>Jeu.java</code></li>
*</ul>
*
*@author Fauconnier/Henriquet
*/
package ScrabbleLancement;