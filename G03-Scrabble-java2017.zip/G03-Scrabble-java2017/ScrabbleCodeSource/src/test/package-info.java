/**
*Ce package contient tous les tests des classes du package Scrabble :
*<ul>
*<li>La classe <code>CaseTest.java</code></li>
*<li>La classe <code>JokerTest.java</code></li>
*<li>La classe <code>JoueurTest.java</code></li>
*<li>La classe <code>LettreTest.java</code></li>
*<li>La classe <code>PlateauTest.java</code></li>
*<li>La classe <code>SacTest.java</code></li>
*</ul>
*
*@author Fauconnier/Henriquet
*/
package test;