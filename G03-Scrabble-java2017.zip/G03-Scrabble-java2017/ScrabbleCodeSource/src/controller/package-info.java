/**
*Ce package contient le controller
*<ul>
*<li>La classe <code>ScrabbleController.java</code></li>
*</ul>
*
*@author Fauconnier/Henriquet
*/
package controller;