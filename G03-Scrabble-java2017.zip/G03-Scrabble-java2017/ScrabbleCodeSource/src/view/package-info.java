/**
*Ce package contient toutes les views (GUI + Console) :
*<ul>
*<li>La classe <code>Bouton.java</code></li>
*<li>La classe <code>ScrabbleView.java</code></li>
*<li>La classe <code>ScrabbleViewConsole.java</code></li>
*<li>La classe <code>ScrabbleViewGUI.java</code></li>
*</ul>
*
*@author Fauconnier/Henriquet
*/
package view;