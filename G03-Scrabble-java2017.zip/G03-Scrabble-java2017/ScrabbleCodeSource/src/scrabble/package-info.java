/**
*Ce package contient toutes les classes du projet Scrabble dont :
*<ul>
*<li>La classe <code>Case.java</code></li>
*<li>La classe <code>Joker.java</code></li>
*<li>La classe <code>Joueur.java</code></li>
*<li>La classe <code>Lettre.java</code></li>
*<li>La classe <code>Plateau.java</code></li>
*<li>La classe <code>Sac.java</code></li>
*</ul>
*
*@author Fauconnier/Henriquet
*/
package scrabble;